/boot:
total 271248
dr-xr-xr-x.  5 0 0      4096 Jun 18 18:59 .
dr-xr-xr-x. 22 0 0      4096 Jul  9 03:00 ..
-rw-r--r--.  1 0 0       169 May 11  2024 .vmlinuz-4.18.0-553.el8_10.x86_64.hmac
-rw-------.  1 0 0   4505309 May 11  2024 System.map-4.18.0-553.el8_10.x86_64
-rw-r--r--.  1 0 0    202201 May 11  2024 config-4.18.0-553.el8_10.x86_64
drwx------   3 0 0      4096 Jan  1  1970 efi
drwx------.  2 0 0        21 Jun 18 18:52 grub2
-rw-------.  1 0 0 105495023 Jun 18 18:52 initramfs-0-rescue-77bbd7bea5c24c338834e5ee080b537b.img
-rw-------.  1 0 0  32521681 Jun 18 20:35 initramfs-4.18.0-553.el8_10.x86_64.img
-rw-------.  1 0 0 113269760 Jun 18 21:46 initramfs-4.18.0-553.el8_10.x86_64kdump.img
drwxr-xr-x.  3 0 0        21 Jun 18 18:51 loader
lrwxrwxrwx.  1 0 0        48 Jun 18 18:51 symvers-4.18.0-553.el8_10.x86_64.gz -> /lib/modules/4.18.0-553.el8_10.x86_64/symvers.gz
-rwxr-xr-x.  1 0 0  10868344 Jun 18 18:51 vmlinuz-0-rescue-77bbd7bea5c24c338834e5ee080b537b
-rwxr-xr-x.  1 0 0  10868344 May 11  2024 vmlinuz-4.18.0-553.el8_10.x86_64

/boot/efi:
total 12
drwx------  3 0 0 4096 Jan  1  1970 .
dr-xr-xr-x. 5 0 0 4096 Jun 18 18:59 ..
drwx------  4 0 0 4096 Jun 18 18:50 EFI

/boot/efi/EFI:
total 16
drwx------ 4 0 0 4096 Jun 18 18:50 .
drwx------ 3 0 0 4096 Jan  1  1970 ..
drwx------ 2 0 0 4096 Jun 18 18:51 BOOT
drwx------ 3 0 0 4096 Jul  1 09:23 redhat

/boot/efi/EFI/BOOT:
total 1036
drwx------ 2 0 0   4096 Jun 18 18:51 .
drwx------ 4 0 0   4096 Jun 18 18:50 ..
-rwx------ 1 0 0 955632 Apr  9  2024 BOOTX64.EFI
-rwx------ 1 0 0  91216 Apr  9  2024 fbx64.efi

/boot/efi/EFI/redhat:
total 4904
drwx------ 3 0 0    4096 Jul  1 09:23 .
drwx------ 4 0 0    4096 Jun 18 18:50 ..
-rwx------ 1 0 0     108 Apr  9  2024 BOOTX64.CSV
drwx------ 2 0 0    4096 Feb 21  2024 fonts
-rwx------ 1 0 0    6647 Jun 18 20:30 grub.cfg
-rwx------ 1 0 0    1024 Jul  1 09:23 grubenv
-rwx------ 1 0 0 2217416 Feb 21  2024 grubx64.efi
-rwx------ 1 0 0  853672 Apr  9  2024 mmx64.efi
-rwx------ 1 0 0  958208 Apr  9  2024 shimx64-redhat.efi
-rwx------ 1 0 0  955632 Apr  9  2024 shimx64.efi

/boot/efi/EFI/redhat/fonts:
total 8
drwx------ 2 0 0 4096 Feb 21  2024 .
drwx------ 3 0 0 4096 Jul  1 09:23 ..

/boot/grub2:
total 4
drwx------. 2 0 0   21 Jun 18 18:52 .
dr-xr-xr-x. 5 0 0 4096 Jun 18 18:59 ..
lrwxrwxrwx. 1 0 0   25 Feb 21  2024 grubenv -> ../efi/EFI/redhat/grubenv

/boot/loader:
total 4
drwxr-xr-x. 3 0 0   21 Jun 18 18:51 .
dr-xr-xr-x. 5 0 0 4096 Jun 18 18:59 ..
drwx------. 2 0 0  130 Jun 18 18:52 entries

/boot/loader/entries:
total 8
drwx------. 2 0 0 130 Jun 18 18:52 .
drwxr-xr-x. 3 0 0  21 Jun 18 18:51 ..
-rw-r--r--. 1 0 0 409 Jun 18 18:52 77bbd7bea5c24c338834e5ee080b537b-0-rescue.conf
-rw-r--r--. 1 0 0 352 Jun 18 18:52 77bbd7bea5c24c338834e5ee080b537b-4.18.0-553.el8_10.x86_64.conf
